run make randomresults

